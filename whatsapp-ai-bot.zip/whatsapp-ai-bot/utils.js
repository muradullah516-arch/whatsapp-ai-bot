// utils.js — helper functions for filtering and context

// Keywords that suggest the message is about web dev services
const RELEVANT_KEYWORDS = [
  'website', 'web', 'site', 'app', 'application', 'design', 'develop',
  'build', 'create', 'make', 'price', 'cost', 'how much', 'quote',
  'portfolio', 'ecommerce', 'store', 'shop', 'landing page', 'wordpress',
  'react', 'html', 'ui', 'ux', 'hire', 'freelance', 'project',
  // Urdu / common local keywords (add more as needed)
  'website banana', 'website chahiye', 'rate', 'kaam', 'project'
];

/**
 * Returns true if the message seems related to web dev services.
 * Returns false for greetings-only or totally unrelated messages.
 */
function shouldReply(text) {
  const lower = text.toLowerCase();

  // Always reply to short greetings — the AI will handle them
  const greetings = ['hi', 'hello', 'salam', 'assalam', 'hey', 'helo', 'aoa'];
  if (greetings.some(g => lower.trim() === g || lower.trim().startsWith(g + ' '))) {
    return true;
  }

  // Reply if any relevant keyword found
  return RELEVANT_KEYWORDS.some(kw => lower.includes(kw));
}

/**
 * Build extra context string for the AI about this contact.
 * Expand this later to include conversation history from a database.
 */
function buildContext(name) {
  return `The customer's name is: ${name}.`;
}

module.exports = { shouldReply, buildContext };
