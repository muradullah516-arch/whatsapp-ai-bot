const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { getAIReply } = require('./ai');
const { shouldReply, buildContext } = require('./utils');

const client = new Client({
  authStrategy: new LocalAuth(), // saves session so you don't scan QR every time
  puppeteer: {
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  }
});

// Show QR code in terminal to scan with your phone
client.on('qr', (qr) => {
  console.log('\n📱 Scan this QR code with WhatsApp on your phone:\n');
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('✅ WhatsApp bot is connected and ready!');
});

client.on('auth_failure', () => {
  console.error('❌ Authentication failed. Delete the .wwebjs_auth folder and restart.');
});

client.on('disconnected', (reason) => {
  console.log('⚠️  Bot disconnected:', reason);
  client.initialize(); // auto-reconnect
});

// Main message handler
client.on('message', async (msg) => {
  try {
    // Ignore group messages, status updates, and messages from yourself
    if (msg.from === 'status@broadcast') return;
    if (msg.fromMe) return;
    if (msg.isGroupMsg) return; // remove this line if you want group support

    const contact = await msg.getContact();
    const name = contact.pushname || contact.number;
    const text = msg.body.trim();

    console.log(`\n💬 Message from ${name}: ${text}`);

    // Check if the message is relevant to web dev services
    if (!shouldReply(text)) {
      console.log('⏭️  Message not relevant, skipping.');
      return;
    }

    // Show "typing..." indicator
    const chat = await msg.getChat();
    await chat.sendStateTyping();

    // Get AI reply
    const context = buildContext(name);
    const reply = await getAIReply(text, context);

    // Send reply
    await msg.reply(reply);
    console.log(`✅ Replied to ${name}`);

  } catch (err) {
    console.error('❌ Error handling message:', err.message);
  }
});

client.initialize();
