// ai.js — handles AI replies via Claude API (or swap for OpenAI below)

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY; // set in .env file

/**
 * Get an AI-generated reply for an incoming WhatsApp message.
 * @param {string} userMessage - the customer's message
 * @param {string} context - extra context about the sender
 * @returns {string} - the reply to send back
 */
async function getAIReply(userMessage, context = '') {
  const systemPrompt = `You are a professional web developer and the virtual assistant for this business.
Your job is to respond to potential clients asking about web development services on WhatsApp.

About this business:
- We build websites, web apps, e-commerce stores, and landing pages
- We work with technologies like HTML, CSS, JavaScript, React, Node.js, and WordPress
- Services include: custom websites, portfolio sites, business websites, online stores, website redesigns
- We provide free consultations before starting any project
- Typical timelines: simple site 1-2 weeks, complex app 4-8 weeks
- Pricing is custom based on requirements (encourage them to share their needs)

Your tone:
- Friendly, professional, and concise — this is WhatsApp, not email
- Reply in short paragraphs (2-4 sentences max per message)
- Always end by asking a follow-up question to understand their needs better
- If someone asks for pricing, say it depends on the project and invite them to share details
- Respond in the SAME LANGUAGE the customer uses

${context}

IMPORTANT: Keep replies short and conversational. No bullet points, no long lists. This is a chat.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 300,
        system: systemPrompt,
        messages: [
          { role: 'user', content: userMessage }
        ]
      })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || 'API error');
    }

    const data = await response.json();
    return data.content[0].text.trim();

  } catch (err) {
    console.error('AI API error:', err.message);
    // Fallback reply if AI fails
    return "Thanks for your message! I'll get back to you shortly. 🙏";
  }
}

module.exports = { getAIReply };

/* ─── OPENAI ALTERNATIVE ───────────────────────────────────────────────────
   To use OpenAI instead of Claude, replace the fetch block above with:

   const { OpenAI } = require('openai');
   const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

   const completion = await openai.chat.completions.create({
     model: 'gpt-4o-mini',
     max_tokens: 300,
     messages: [
       { role: 'system', content: systemPrompt },
       { role: 'user', content: userMessage }
     ]
   });
   return completion.choices[0].message.content.trim();
──────────────────────────────────────────────────────────────────────────── */
