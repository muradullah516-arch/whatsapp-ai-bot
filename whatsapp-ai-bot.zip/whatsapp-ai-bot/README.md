# WhatsApp AI Bot — Web Developer Assistant

A WhatsApp bot that automatically replies to clients asking about your web development services.
Uses QR code login (no official WhatsApp API needed) and AI-powered replies.

---

## Setup (Step by Step)

### 1. Install Node.js
Download from https://nodejs.org — use version 18 or higher.

### 2. Install dependencies
```bash
npm install
```

> Note: whatsapp-web.js installs Chromium automatically. This may take a few minutes.

### 3. Add your API key
```bash
cp .env.example .env
```
Open `.env` and paste your Claude API key.
Get one free at: https://console.anthropic.com

### 4. Start the bot
```bash
npm start
```

### 5. Scan the QR code
- Open WhatsApp on your phone
- Go to Settings → Linked Devices → Link a Device
- Scan the QR code shown in your terminal

Your bot is now live! ✅

---

## How it works

- `index.js` — connects to WhatsApp, listens for messages
- `ai.js` — sends messages to Claude AI and gets replies
- `utils.js` — filters messages (only replies to web dev related ones)

---

## Customization

### Change what the bot says about your services
Edit the `systemPrompt` in `ai.js`. Update:
- Your services list
- Your pricing info
- Your tone and style

### Add more trigger keywords (Urdu, Pashto, etc.)
Edit `RELEVANT_KEYWORDS` in `utils.js`

### Reply to group messages too
In `index.js`, remove or comment out this line:
```js
if (msg.isGroupMsg) return;
```

---

## Next Steps (Phase 3 & 4)
- Add conversation memory (SQLite)
- Build a web dashboard
- Deploy to a VPS so it runs 24/7
